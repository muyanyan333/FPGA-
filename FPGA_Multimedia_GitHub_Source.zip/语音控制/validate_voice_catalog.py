"""Validate ASRPRO timeout and every real W02 parser result against the UART catalog."""
import json
import re
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

from build_asrpro_project import ROOT, NS, OUTPUT, commands, SLEEP_TIMEOUT_SECONDS

entries = commands()
root = ET.parse(OUTPUT).getroot()
timeout = root.find(f".//{{{NS}}}block[@type='asr_easystart_setup']/{{{NS}}}field[@name='second']")
assert timeout is not None and int(timeout.text) == SLEEP_TIMEOUT_SECONDS == 1000
script_parts = []
for directory in ("lab_ex5_i2s-work", "lab_ex5_i2s"):
    path = ROOT.parent / directory / "bluetooth_image_controller.html"
    html = path.read_text(encoding="utf-8")
    code = re.search(r"<script>([\s\S]*?)</script>", html).group(1)
    catalog = code[code.index("  const voiceCommandCatalog ="):code.index("  let voiceRecognition")]
    parser = code[code.index("  function voiceNumber("):code.index("  function voiceFeedback(")]
    songs = re.search(r"  const songNames = .*?;", code).group(0)
    expected = [[e.phrase, e.command, e.argument, e.response] for e in entries]
    script_parts.append("new Function(" + json.dumps(code, ensure_ascii=False) + ");\n{\n" + songs + catalog + parser + "\nconst expected=" + json.dumps(expected, ensure_ascii=False) + ";\n" + """
for (const [phrase, command, argument, reply] of expected) {
  for (const utterance of [phrase, '小美，' + phrase + '，好吗']) {
    const actual = parseVoiceCommand(utterance);
    if (!actual || (command === null ? actual.reply !== reply :
        actual.command !== command || actual.argument !== argument)) {
      throw new Error('Voice catalog mismatch: ' + utterance + ' ' + JSON.stringify(actual));
    }
  }
}
for (const text of ['不要打开摄像头','小美别切换下一张','请不要暂停音乐','不用返回相册',null,42]) {
  if (parseVoiceCommand(text) !== null) throw new Error('Unexpected command: ' + text);
}
console.log(`PASS: ${expected.length} commands, ${expected.length} wake-word/polite variants, negative and invalid inputs`);
}\n""")
    if "  async function sendDisplayMode(mode)" in code:
        mode_function = code[code.index("  async function sendDisplayMode(mode)"):code.index("  function voiceNumber(")]
        ack = code[code.index("      if (frame[1] === 0x86 &&"):code.index("      rxFrameCount++;")]
        script_parts.append("{\n" + """
let pendingDisplayMode=null, displayModeRequestId=0, displayModeTimer=null;
let linkToken=0, demoMode=false, state={displayMode:0};
let timers=new Map(), timerId=0, messages=[];
const render=()=>{}, log=value=>messages.push(value);
const setTimeout=fn=>{timers.set(++timerId,fn);return timerId;};
const clearTimeout=id=>timers.delete(id);
let sendCommand=async()=>true;
function acknowledge(mode) {
  const frame=[0x5A,0x86]; state.displayMode=mode;
""" + ack + "\n}\n" + mode_function + """
async function checkModes() {
  const assert=(condition,label)=>{if(!condition) throw new Error(label);};
  await sendDisplayMode(1);
  acknowledge(0); assert(pendingDisplayMode===1,'stale status confirmed wrong mode');
  acknowledge(1); assert(pendingDisplayMode===null && timers.size===0,'matching ACK not cleared');
  await sendDisplayMode(0);
  timers.get(displayModeTimer)();
  assert(pendingDisplayMode===null && messages.length===1,'timeout not handled');
  let completeFirst;
  sendCommand=(command,arg)=>command===0x1D && arg===1 ?
    new Promise(resolve=>{completeFirst=resolve;}) : Promise.resolve(true);
  const first=sendDisplayMode(1);
  await sendDisplayMode(0);
  completeFirst(false); await first;
  assert(pendingDisplayMode===0,'old failure overwrote new request');
  acknowledge(0);
  const stale=sendDisplayMode(1);
  linkToken++; pendingDisplayMode=null; completeFirst(true); await stale;
  assert(pendingDisplayMode===null,'old connection changed current request');
  assert(await sendDisplayMode(7)===false,'invalid mode accepted');
  console.log('PASS: matching ACK, timeout, overlapping requests, reconnect, invalid mode');
}
checkModes().catch(error=>{console.error(error);process.exitCode=1;});
}\n""")
with tempfile.TemporaryDirectory() as temp:
    test = Path(temp) / "voice_catalog_check.js"
    test.write_text("\n".join(script_parts), encoding="utf-8")
    subprocess.run(["node", str(test)], check=True)
print("PASS: ASRPRO timeout 1000 seconds; generated XML is readable")
