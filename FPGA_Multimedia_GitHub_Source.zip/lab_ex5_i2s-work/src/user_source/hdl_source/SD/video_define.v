`define	VIDEO_640_480
